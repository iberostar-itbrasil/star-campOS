const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  sendNav: (action) => ipcRenderer.send('nav-action', action)
});
