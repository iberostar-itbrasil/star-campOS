const { app, BrowserWindow, BrowserView, ipcMain } = require('electron');
const path = require('path');

let win;
let contentView;
let navView;

const campus_url = 'https://starteam.grupoiberostar.com/pt/sessao/novo';

function createWindow() {
  win = new BrowserWindow({
    kiosk: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  });

  win.setMenu(null);

  contentView = new BrowserView({
    webPreferences: {
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  navView = new BrowserView({
    webPreferences: {
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });


  win.setBrowserView(contentView);
  win.addBrowserView(navView);

  contentView.webContents.loadURL(campus_url);
  navView.webContents.loadFile('navbar.html');

  function resizeViews() {
    const [width, height] = win.getContentSize();
    const navbarHeight = 70;

    contentView.setBounds({ x: 0, y: 0, width, height: height - navbarHeight });
    navView.setBounds({ x: 0, y: height - navbarHeight, width, height: navbarHeight });
  }

  win.on('resize', resizeViews);
  resizeViews();

  contentView.webContents.setWindowOpenHandler(({ url }) => {
    contentView.webContents.loadURL(url);
    return { action: 'deny' };
  });

  ipcMain.on('nav-action', (_, action) => {
    if (action === 'home') {
      contentView.webContents.loadURL(campus_url);
    } else if (action === 'back') {
      if (contentView.webContents.canGoBack()) {
        contentView.webContents.goBack();
      }
    } else if (action === 'close') {
      app.quit();
    }
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
