let tabHistory = {}; // Store parent-child relationships


// Go home step
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "goHome") {
    chrome.tabs.update(sender.tab.id, { url: "https://starteam.grupoiberostar.com/sesion/nuevo" });
  }
});


// Close current page and redirect to last visted page
chrome.tabs.onCreated.addListener((newTab) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const parentTabId = tabs[0].id;
      tabHistory[newTab.id] = parentTabId; // Store parent tab ID
    }
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "goBack") {
    const parentTabId = tabHistory[sender.tab.id];

    if (parentTabId) {
      chrome.tabs.update(parentTabId, { active: true }); // Switch to parent tab
      chrome.tabs.remove(sender.tab.id); // Closes the current tab
    }
  }
});

// CLose all tabs at the same time
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "closeBrowser") {
    chrome.windows.getAll({ populate: true }, (windows) => {
      windows.forEach((win) => {
        chrome.windows.remove(win.id); // Closes all open windows
      });
    });
  }
});
