// Create navigation bar
const navBar = document.createElement("div");
navBar.id = "custom-nav-bar";
navBar.innerHTML = `
  <button id="home-btn" class="campus-menu-btn">
     <svg width="30" height="30" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
        <path d="M3 10L12 2L21 10V20C21 20.55 20.55 21 20 21H16C15.45 21 15 20.55 15 20V15C15 14.45 14.55 14 14 14H10C9.45 14 9 14.45 9 15V20C9 20.55 8.55 21 8 21H4C3.45 21 3 20.55 3 20V10Z"/>
    </svg>
  </button>
    
  <button id="back-btn" class="campus-menu-btn">
    <svg width="35" height="35" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
      <path d="M20 12H4M10 6L4 12L10 18" stroke="white" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </button>
  
  <button id="close-btn" class="campus-menu-btn">
    <svg width="30" height="30" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg">
      <path d="M18 6L6 18M6 6L18 18" stroke="white" stroke-width="4" stroke-linecap="round"/>
    </svg>
  </button>
`;

// Apply styles
document.body.appendChild(navBar);

// Event listeners
document.getElementById("home-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "goHome" });
});

document.getElementById("back-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "goBack" });
});

document.getElementById("close-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "closeBrowser" });
});
